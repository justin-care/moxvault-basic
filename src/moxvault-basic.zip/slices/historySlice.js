import { createSlice } from "@reduxjs/toolkit";
import { initialState as gameInitialState } from "./gameSlice";
import gameReducer, * as gameActions from "./gameSlice";
import { current } from "@reduxjs/toolkit";

const initialState = {
    past: [],
    present: structuredClone(gameInitialState),
    future: []
}

const historySlice = createSlice({
    name: "history",
    initialState,
    reducers: {
        undo: (state) => {
            console.log('undo');
            if(state.past.length > 0) {
                const clonedPresent = JSON.parse(JSON.stringify(current(state.present)));
                state.past.push(clonedPresent);
                state.present = JSON.parse(JSON.stringify(state.past.pop()));
            } else {
                state.present.undoActive = false;
            }
        },
        redo: (state) => {
            if(state.future.length > 0) {
                const clonedPresent = JSON.parse(JSON.stringify(current(state.present)));
                state.past.push(clonedPresent);
                state.present = JSON.parse(JSON.stringify(state.future.pop()));
            } else {
                state.present.redoActive = false;
            }
        },
        reset: (state) => {
            const clonedPresent = JSON.parse(JSON.stringify(current(state.present)));
            state.past.push(clonedPresent);
            state.present = JSON.parse(JSON.stringify(gameInitialState));
            state.future = [];
        },
        dispatchGameAction: (state, action) => {
            const clonedPresent = JSON.parse(JSON.stringify(current(state.present)));
            const newState = gameReducer(clonedPresent, action.payload);

            if (JSON.stringify(newState) !== JSON.stringify(clonedPresent)) {
                state.past.push(clonedPresent);
                state.present = newState;
                state.future = [];

                console.log("Past after push:", state.past.map(p => p.players));
                state.present.undoActive = state.past.length > 0;
                state.present.redoActive = state.future.length > 0;
                state.present.resetActive = state.past.length > 0;
            }
        },
    }
});

export const { undo, redo, reset, dispatchGameAction } = historySlice.actions;
export default historySlice.reducer;
export {gameActions};