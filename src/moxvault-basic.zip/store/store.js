import { configureStore } from "@reduxjs/toolkit";
import gameReducer from "../slices/historySlice";

const store = configureStore({
    reducer: {
        game: gameReducer
    },
});

export default store;