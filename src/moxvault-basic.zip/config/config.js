const config = {
    showGameId: false
}

export default config